<?php
// Heading
$_['heading_title']    = 'Ajax каталог by Artem Pitov';

// Text
$_['text_extension']   = 'Модули';
$_['text_success']     = 'Настройки модуля обновлены!';
$_['text_edit']        = 'Редактирование модуля';

// Entry
$_['entry_status']     						= 'Статус';
$_['entry_container']				        = 'Контейнер <br> (jQuery селектор)';
$_['entry_loader_status']			        = 'Визуальный загрузчик';
$_['entry_scroll_offset']			        = 'Отступ прокрутки <br> (пиксели)';
$_['entry_scroll_duration']			        = 'Скорость прокрутки <br> (миллисекунды)';
$_['entry_scroll_timeout']			        = 'Задержка прокрутки <br> (миллисекунды)';
$_['entry_navigation_wrapper']			    = 'Обертка навигации <br> (jQuery селектор)';
$_['entry_navigation_pagination_status']	= 'Ajax пагинация';
$_['entry_navigation_pagination_active']	= 'Активный элемент пагинации <br> (jQuery селектор)'; 
$_['entry_navigation_pagination_selector']	= 'Пагинация <br> (jQuery селектор)';
$_['entry_navigation_button_status']		= 'Кнопка "Показать еще"';
$_['entry_navigation_button_selector']		= 'Кнопка "Показать еще" <br> (jQuery селектор)';
$_['entry_filter_sort_order_status']		= 'Ajax сортировка';
$_['entry_filter_sort_order_selector']		= 'Cортировка <br> (jQuery селектор)';
$_['entry_filter_limit_status']				= 'Ajax лимит';
$_['entry_filter_limit_selector']			= 'Лимит <br> (jQuery селектор)';
$_['entry_products_selector']				= 'Товар <br> (jQuery селектор)';
$_['entry_products_wrapper']				= 'Обертка товаров <br> (jQuery селектор)';
$_['entry_url_reload_status']				= 'Изменять URL';
$_['entry_url_replace_status']				= 'Сохранения истории';

// Error
$_['error_permission'] = 'У вас нет прав для управления этим модулем!';
