<?php
/**
 * More JS by Artem Pitov (c) 2018
 *
 * @author Artem Pitov <artempitov@gmail.com>
 * @link https://www.pitov.pro
 * @link https://opencartforum.com/user/674600
 *
 * @license Сommercial license
 */

class ControllerExtensionModuleMore extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/module/more');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('more', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/module/more', 'token=' . $this->session->data['token'], true));
		}

		$data = $this->language->all();

		$data['error_warning'] = isset($this->error['warning']) ? $this->error['warning'] : false;

		$data['breadcrumbs'] = 
		[
			[
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard',    'token=' . $this->session->data['token'], true)
			],
			[
				'text' => $this->language->get('text_extension'),
				'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true)
			],
			[
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('extension/module/more', 'token=' . $this->session->data['token'], true)
			]
		];

		if (isset($this->request->post['more_settings'])) {
			$data['more'] = $this->request->post['more_settings'];
		} elseif ($this->config->has('more_settings')) {
			$data['more'] = $this->config->get('more_settings');
		} else {
			$data['more'] = [];
		}	

		$data['action']      = $this->url->link('extension/module/more', 'token=' . $this->session->data['token'], true);
		$data['cancel']      = $this->url->link('extension/extension',   'token=' . $this->session->data['token'] . '&type=module', true);
		$data['more_data']   = isset($this->request->post['more_data']) ? $this->request->post['more_data'] : $this->config->get('more_data'); 
		$data['header']      = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer']      = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/more', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/more')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
}
