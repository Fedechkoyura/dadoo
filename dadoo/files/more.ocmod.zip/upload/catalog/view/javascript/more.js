/** 
 * Load More by Artme Pitov <artempitov@gmail.com>
 * https://pitov.pro
 */
~(function($) {
 	const DEFAULT = 
 	{
 		container  : '#content',
 		loader     : 
 		{
 			status : false,
 			image  : false
 		},
 		scroll 	   : 
 		{
 			offset   : 0,
 			duration : 500,
 			timeout  : 100
 		},
 		navigation : 
 		{
 			wrapper : '.jq-more', 
	 		pagination : 
	 		{
	 			ajax     : false,
	 			active   : 'li.active',
	 			selector : '.pagination'
	 		},
	 		button : 
	 		{
	 			ajax     : true,
	 			selector : '[data-targer="jq-more"]'
	 		} 
 		},	
 		filter : 
 		{
	 		sort_order :   
	 		{
	 			ajax     : false,
	 			selector : '#input-sort'
	 		},
	 		limit : 
	 		{
	 			ajax : false,
	 			selector : '#input-limit'
	 		},
	 		catalog : 
	 		{
	 			sub : 
	 			{
	 				ajax     : false,
	 				selector : false
	 			}
	 		}
 		},
 		products : 
 		{
 			selector : '.product-layout',
 			wrapper  : '.row'
 		},
 		url : 
 		{
 			reload  : false, // Reload URL 
 			replace : false  // Replace URL 
 		}
 	}

 	let More = function(options) 
 	{	
 		this.options = $.extend(true, {}, DEFAULT, typeof options == 'object' && options)

 		/* pagination */
 		this.options.navigation.pagination.ajax && this.initPagination()

 		/* button */
 		this.options.navigation.button.ajax && this.initButton()

 		/* sort order */
 		if (this.options.filter.sort_order.ajax) {
 			$(this.options.filter.sort_order.selector).removeAttr('onchange')
 			this.initSortOrder()	
 		}

 		/* limit */
 		if(this.options.filter.limit.ajax) {
 			$(this.options.filter.limit.selector).removeAttr('onchange')
 			this.initLimit()
 		}

 		/* replace url */
 		if (this.options.url.replace) {
			$(this.options.products.selector).data('location', window.location.href)
			
			this.initReplaceUrl()
		}

 		// console.log(this.options)
 	}

 	More.prototype.initPagination = function() 
 	{
 		let self   = this, 
 		pagination = self.options.container + ' ' + self.options.navigation.pagination.selector + ' a'

 		$(document).on('click', pagination, function(e) {
 			e.preventDefault()

 			let url = $(this).attr('href')

 			if (url.length) {
 				self.rendering(url, true)
 			}
 		})
 	}

 	More.prototype.initButton = function() 
 	{
 		let self = this

 		$(document).on('click', self.options.navigation.button.selector, function(e) {
 			e.preventDefault()

 			let _this  = this
 			let action = $(_this).closest(self.options.navigation.wrapper)
 								 .find(self.options.navigation.pagination.selector + ' ' + self.options.navigation.pagination.active)
 								 .next()

			if (action.length) {
				self.BtnLoading(_this, 'loading')

				let a   = action.children('a'),
					url = a.length ? a.attr('href') : action.attr('href')

				if (url.length) {
					self.rendering(url)
						.done(() => self.BtnLoading(_this, 'reset') )
				} else {
					self.BtnLoading(_this, 'reset')
				}
			} 	
 		})
 	}

 	More.prototype.initSortOrder = function() 
 	{
 		let self = this 
 		
 		$(document).on('change', self.options.container + ' ' + self.options.filter.sort_order.selector, function (e) {
 			e.preventDefault()

 			let url = $(this).val()

 			if (url.length) {
 				self.rendering(url, true)
 			}
 		})
 	}

 	More.prototype.initLimit = function() 
 	{
 		let self = this 
 		
 		$(document).on('change', self.options.container + ' ' + self.options.filter.limit.selector, function (e) {
 			e.preventDefault()

 			let url = $(this).val()

 			if (url.length) {
 				self.rendering(url, true)
 			}
 		})
 	} 	

 	/* Rendering */
 	More.prototype.rendering = function(url, replace = false) 
 	{
 		let self       = this,
			product    = self.options.container + ' ' + self.options.products.selector,
			pagination = self.options.container + ' ' + self.options.navigation.wrapper,
			sort_order = self.options.container + ' ' + self.options.filter.sort_order.selector,
			limit 	   = self.options.container + ' ' + self.options.filter.limit.selector

		$(pagination + ' a, ' + pagination + ' button').prop('disabled', true)

		/* loader */
		self.options.loader.status && this.initLoader()
       
 		return $.get(url, (response) => {

 			/* collback */
 			self.beforeRendering(self)

 			let $response         = $(response),
 				response_product  = $response.find(product)

 			if (response_product.length) {
 				let $product_first = $(product + ':first');

 				response_product.attr('class', $product_first.attr('class'))
 				
 				/* replace url */
 				self.options.url.replace && response_product.data('location', url)

 				/* products */
 				replace ? 
 					$product_first
 						.closest(self.options.products.wrapper)
 						.html(response_product) 
 					: $(product + ':last')
 						.after(response_product)
 				
 				/* pagination */
 				$(pagination).html($($response.find(pagination)).html())

 				/* sort_order */
 				if (self.options.filter.sort_order) {
 					let response_sort_order = $response.find(sort_order)
 					
 					response_sort_order.length && $(sort_order).html($(response_sort_order).html())
 				}

 				/* limit */
 				if (self.options.filter.limit) {
 					let response_limit = $response.find(limit)
 					
 					response_limit.length && $(limit).html($(response_limit).html())
 				}
 			}

 			/* collback */
 			self.afterRendering(self)

 		}, 'html')
 			.done(function() { 
 				/* reload url */
 				self.options.url.reload && self.history.reload(url)

 				/* loader */
				self.options.loader.status && $('#jq-more-loader').remove()

				if (replace) {
					let scroll_to = $(self.options.filter.sort_order.selector)

					scroll_to = scroll_to.length ? scroll_to : $(self.options.filter.limit.selector)
					scroll_to = scroll_to.length ? scroll_to.offset().top : 0

					$('html,body').animate({scrollTop : scroll_to - self.options.scroll.offset}, self.options.scroll.duration)
				}
 			})
 	}

 	/* replace url */
 	More.prototype.initReplaceUrl = function() 
 	{
 		let self = this 

 		if (sessionStorage.getItem('jqMore')) {
 			setTimeout(() => {
 				let offset = $(self.options.container + ' ' + self.options.products.selector + 
 					' a[href="' + sessionStorage.getItem('jqMore') + '"]:first').closest(self.options.products.selector)

 				if (offset.length) {
 					offset = offset.offset()

 					$('html,body').animate({scrollTop : offset.top - self.options.scroll.offset}, self.options.scroll.duration)
 				}

 				sessionStorage.removeItem('jqMore')
 			}, self.options.scroll.timeout); 
 		}

 		$(document).on('click', self.options.products.selector + ' > *', function () {

 			let mark     = $(this).closest(self.options.products.selector).find('a:first').attr('href'), 
 				location = $(this).closest(self.options.products.selector).data('location')

 			window.onbeforeunload = function(e) {
				if (mark && location) {
					sessionStorage.setItem('jqMore', mark)

					if (window.location.href != location) {
						self.history.replace(location)
					}
				} 				
 			}
 		});
 	}

 	/* URL & History */
 	More.prototype.history =  
 	{
 		reload  : (url) => window.history.pushState(null, null, url),
 		replace : (url) => window.history.replaceState(null, null, url)
 	}

 	/* Collback */
 	More.prototype.beforeRendering = function($this) 
 	{
 		// console.log($this);
 	} 

 	More.prototype.afterRendering = function($this) 
 	{
 		// console.log($this);

 		// Unishop 
 		typeof autoheight == 'function' && autoheight()
 	}
 	/* Collback */

 	/* Loader */
 	More.prototype.initLoader = function() 
 	{
 		let svg  = `<svg class="lds-spinner" width="60px" height="60px" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid" style="background: none;"><g transform="rotate(0 50 50)"><rect x="47.5" y="19" rx="9.5" ry="3.8000000000000003" width="5" height="12" fill="#0055a5"><animate attributeName="opacity" values="1;0" keyTimes="0;1" dur="1.7s" begin="-1.4875s" repeatCount="indefinite"></animate></rect></g><g transform="rotate(45 50 50)"><rect x="47.5" y="19" rx="9.5" ry="3.8000000000000003" width="5" height="12" fill="#0055a5"><animate attributeName="opacity" values="1;0" keyTimes="0;1" dur="1.7s" begin="-1.275s" repeatCount="indefinite"></animate></rect></g><g transform="rotate(90 50 50)"><rect x="47.5" y="19" rx="9.5" ry="3.8000000000000003" width="5" height="12" fill="#0055a5"><animate attributeName="opacity" values="1;0" keyTimes="0;1" dur="1.7s" begin="-1.0625s" repeatCount="indefinite"></animate></rect></g><g transform="rotate(135 50 50)"><rect x="47.5" y="19" rx="9.5" ry="3.8000000000000003" width="5" height="12" fill="#0055a5"><animate attributeName="opacity" values="1;0" keyTimes="0;1" dur="1.7s" begin="-0.85s" repeatCount="indefinite"></animate></rect></g><g transform="rotate(180 50 50)"><rect x="47.5" y="19" rx="9.5" ry="3.8000000000000003" width="5" height="12" fill="#0055a5"><animate attributeName="opacity" values="1;0" keyTimes="0;1" dur="1.7s" begin="-0.6375s" repeatCount="indefinite"></animate></rect></g><g transform="rotate(225 50 50)"><rect x="47.5" y="19" rx="9.5" ry="3.8000000000000003" width="5" height="12" fill="#0055a5"><animate attributeName="opacity" values="1;0" keyTimes="0;1" dur="1.7s" begin="-0.425s" repeatCount="indefinite"></animate></rect></g><g transform="rotate(270 50 50)"><rect x="47.5" y="19" rx="9.5" ry="3.8000000000000003" width="5" height="12" fill="#0055a5"><animate attributeName="opacity" values="1;0" keyTimes="0;1" dur="1.7s" begin="-0.2125s" repeatCount="indefinite"></animate></rect></g><g transform="rotate(315 50 50)"><rect x="47.5" y="19" rx="9.5" ry="3.8000000000000003" width="5" height="12" fill="#0055a5"><animate attributeName="opacity" values="1;0" keyTimes="0;1" dur="1.7s" begin="0s" repeatCount="indefinite"></animate></rect></g></svg>`
 		let html = `<div id="jq-more-loader" style="position:absolute; z-index: 999; background: rgba(255, 255, 255, .5); left: 0; right: 0; top: 0; bottom: 0;"><span style="position:absolute; left: 50%; top: 50%; transform: translateX(-50%)">`;

 		if (this.options.loader.image) {
 			html += this.options.loader.image
 		} else {
 			html += svg
 		} 
 		
 		html += `</span></div>`;
 		
 		let $container = $($(this.options.products.selector + ':first').closest(this.options.products.wrapper))

 		$container.css({position : 'relative'})

 		$(html).appendTo($container)
 	} 	

 	More.prototype.BtnLoading = function($this, type) 
 	{
 		$this = $($this)

 		switch (type) 
 		{
 			case 'loading':
 				if (typeof $this.data('loading-text') != undefined) {
 					$this.data('reset-text', $this.html())
 					$this.html($this.data('loading-text'))
 				}
 				break

 			case 'reset':
 				if (typeof $this.data('reset-text') != undefined) {
 					$this.html($this.data('reset-text'))
 				} 			
 				break  
 		}
 	}

 	/* Plugins */
	/*function Plugin(options) {
        return this.each(function () {
            if (!$.data(this, 'jq.more')) {
                $.data(this, 'jq.more', new More(this, $.extend(true, {}, DEFAULT, typeof options == 'object' && options)));
            }
        });
	}*/ 	

 	let no_conflict = window.More

 	window.More = More

 	/* No conflict */
 	window.More.noConflict = function() 
 	{
 		window.More = no_conflict
 		return this
 	}
})(jQuery);