<?php
/* All rights reserved belong to the module, the module developers http://opencartadmin.com */
// https://opencartadmin.com � 2011-2019 All Rights Reserved
// Distribution, without the author's consent is prohibited
// Commercial license
include(DIR_LANGUAGE.'english/seocms/catalog/blog.php');
