<?php
$ascp_settings_settings = Array(
'css' => Array('css' => '.seocmspro_content #tab-product-related .owl-carousel {
display: block !important;
}
.seocmspro_content #tab-product-related .owl-moneymaker2-products .product-layout.product-grid {
    width: 33% !important;
}'));
