CKEditor 4.13.0 Full for Opencart 3 + Filemanager Fix + download files (not images)

Works at Opencart 3.

CKEditor - popular WYSIWYG HTML-editor, is often used in CMS Opencart instead of standard Summernote.
Flexible, functional, expanded by means of plugins, checked by time.

In addition communication of the editor with the standard CMS Opencart file manager is implemented.

The standard file manager is improved:
- save of the last folder;
- transliteration of the Russian names of files;
- replacement of incorrect characters in names of files;
- an opportunity to include loading and an insert in the description of other types of the files (not only images) specified in settings of shop.

Installation instruction:
1) Download archive;
2) Install with the standard extension installer;
3) Refresh Modifications;
4) Come into settings of shop in the "Server" tab and select CKEditor as default editor; 
5) Open Products/Categories/Information page on editing and are convinced that the editor is initialized.
Then we try to insert the picture if everything passes successfully - we enjoy life if is not present, we report about a problem and I to you will help to solve it within support.

If you have a problem or question, mail to web-mehanik@yandex.ru.
If you need help to setup, be ready to give ftp-access to the site or send me files. 
