﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('autosave', 'de', {
    dateFormat: 'LLL',
    autoSaveMessage: 'Automatisch gespeichert',
    loadSavedContent: 'Es wurde ein autom. Gespeicherter Inhalt gefunden (vom "{0}"). Wollen Sie den Inhalt vergleichen, um dann entscheiden zu können ob der Inhalt geladen werden soll?',
    title: 'Temp. Gespeichert Inhalt vergleichen',
    loadedContent: 'Geladener Inhalt',
    localStorageFull: 'Browser localStorage is full, clear your storage or Increase database size',
    autoSavedContent: 'Autom. Gespeicherten Inhalt (vom: \'',
    ok: 'Ja, Lade Autom. Gespeicherten Inhalt',
    no: 'Nein',
  diffType: 'Diff Anzeigetyp:',
    sideBySide: 'Nebeneinander',
    inline: 'Inline'
});
