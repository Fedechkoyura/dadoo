﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('autosave', 'eu', {
    dateFormat: 'LLL',
    autoSaveMessage: 'Automatikoki gorde da',
    loadSavedContent: 'Eduki honen automatikoki gordetako "{0}"(e)ko bertsio bat aurkitu da. Edukien bertsioak konparatu eta zein kargatu aukeratu nahi duzu? Utzi botoian klik eginez gero aurrez automatikoki gordetako edukia ezabatuko da.',
    title: 'Konparatu automatikoki gordetako edukia webgunetik kargatutakoarekin',
    loadedContent: 'Kargatutako edukia', 
    localStorageFull: 'Nabigatzailearen biltegiratze lokala beteta dago, garbitu biltegiratzea edo handitu datu-basearen tamaina',
    autoSavedContent: 'Hemendik automatikoki gordetako edukia: \'',
  ok: 'Bai, kargatu automatikoki gordetako edukia',
  no: 'Ez',
  diffType: 'Aukeratu ikuspegi mota:',
  sideBySide: 'Alboz-alboko ikuspegia',
  inline: 'Lineako ikuspegia'
});
