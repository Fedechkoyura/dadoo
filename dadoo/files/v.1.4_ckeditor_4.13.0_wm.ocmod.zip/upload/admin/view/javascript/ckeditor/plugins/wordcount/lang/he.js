﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'he', {
    WordCount: 'מילים:',
    CharCount: 'תווים:',
    CharCountWithHTML: 'תווים (כולל HTML):',
    Paragraphs: 'פסקאות:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'לא ניתן להדביק תוכן בשל עודף תווים',
    Selected: 'נבחר: ',
    title: 'סטטיסטיקות'
});