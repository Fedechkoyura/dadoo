﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'codemirror', 'pl', {
	toolbar: 'Źródło dokumentu',
	autoFormat: 'Sformatuj zaznaczenie',
	commentSelectedRange: 'Zakomentuj zaznaczenie',
	uncommentSelectedRange: 'Odkomentuj zaznaczenie',
	searchCode: 'Wyszukaj w źródle',
	autoCompleteToggle: 'Włącza/Wyłącza automatyczne uzupełniania tagów HTML'
});
