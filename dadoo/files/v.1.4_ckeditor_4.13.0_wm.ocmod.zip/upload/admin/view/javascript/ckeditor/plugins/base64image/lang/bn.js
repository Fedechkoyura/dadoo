/*
Translation from original CKEDITOR language files:
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("base64image","bn",{
	"alt":"বিকল্প টেক্সট",
	"lockRatio":"অনুপাত লক কর",
	"vSpace":"ভার্টিকেল স্পেস",
	"hSpace":"হরাইজন্টাল স্পেস",
	"border":"বর্ডার"
});