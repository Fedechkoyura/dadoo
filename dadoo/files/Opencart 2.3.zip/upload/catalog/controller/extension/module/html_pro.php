<?php
class ControllerExtensionModuleHtmlPro extends Controller {
	public function index($setting) {
		$this->load->language('extension/module/html_pro');

		$this->load->model('tool/image');

		$data['language_id'] = $this->config->get('config_language_id');

		$data['class_wrapper'] = $setting['class_wrapper'];
		$data['class_container'] = $setting['class_container'];

		$data['id_wrapper'] = $setting['id_wrapper'];
		$data['id_container'] = $setting['id_container'];

		$data['heading_title'] = html_entity_decode($setting['wrapper'][$this->config->get('config_language_id')]['name_heading'], ENT_QUOTES, 'UTF-8');

		if (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) {
			$server = $this->config->get('config_ssl');
		} else {
			$server = $this->config->get('config_url');
		}
		
		$results = $setting['item'];

		foreach ($results as $result) {

			if (is_file(DIR_IMAGE . $result['image'])) {
				$image = $server . 'image/' . $result['image'];
			} else {
				$image = '';
			}

			$data['items'][] = array(
				'image' => $image,
				'icon' => $result['icon'],
				'title' => $result['title'],
				'description' => html_entity_decode($result['description'][$this->config->get('config_language_id')], ENT_QUOTES, 'UTF-8'),
				'link' => $result['link'],
				'sort' => $result['sort'],
				'class_item' => $result['class_item'],
				'class_item_child_block' => $result['class_item_child_block'],
				'class_item_img_icon' => $result['class_item_img_icon'],
				'class_item_caption' => $result['class_item_caption'],
				'class_item_title' => $result['class_item_title'],
				'class_item_description' => $result['class_item_description'],
				'id_item' => $result['id_item'],
				'id_item_child_block' => $result['id_item_child_block'],
				'id_item_img_icon' => $result['id_item_img_icon'],
				'id_item_caption' => $result['id_item_caption'],
				'id_item_title' => $result['id_item_title'],
				'id_item_description' => $result['id_item_description'],
				'radio_child_block' => $result['radio_child_block'],
				'radio_img_icon' => $result['radio_img_icon'],
				'radio_caption' => $result['radio_caption']				
			);	
		}

		if (!empty($data['items'])){
			foreach ($data['items'] as $key => $value) {
				$sort[$key] = $value['sort'];
			} 
			array_multisort($sort, SORT_ASC, $data['items']);
		}

		return $this->load->view('extension/module/html_pro', $data);
	}
}