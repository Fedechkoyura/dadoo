<?php
// Heading
$_['heading_title']				= 'HTML Pro';

// Text
$_['text_module']				= 'Модули';
$_['text_extension']    		= 'Модули';
$_['text_success']				= 'Вы успешно сохранили настройки модуля!';
$_['text_edit']					= 'Редактировать модуль';
$_['text_yes']					= 'Да';
$_['text_no']					= 'Нет';
$_['text_off']					= 'Выкл.';
$_['text_name_module']			= 'Название модуля';
$_['text_name_wrapper']			= 'Заголовок';
$_['text_name_item']			= 'Заголовок блока';
$_['text_general_setting']		= 'Общие настройки';
$_['text_item']					= 'Родительский блок';
$_['text_item_img_icon']		= 'Блок для изображения или иконки';
$_['text_image']				= 'Изображение';
$_['text_item_title']			= 'Блок для заголовока';
$_['text_item_description']		= 'Блок для описания';
$_['text_item_caption']			= 'Родительский блок для заголовка и описания';
$_['text_item_child_block']		= 'Дочерний блок';
$_['text_class']				= 'Class';
$_['text_id']					= 'ID';
$_['text_ico']					= 'Иконка';
$_['text_icon']					= 'fa fa-font-awesome';
$_['text_sort']					= 'Сортировка';

// Tabs
$_['tab_setting']				= 'Общие';
$_['tab_items']					= 'Блоки';
$_['tab_info']					= 'О модуле';
$_['tab_item']					= 'Блок';
$_['tab_id_class']				= 'Настройка Class / ID';

// Entry
$_['entry_name_module']			= 'Название модуля:';
$_['entry_name_wrapper']		= 'Заголовок:';
$_['entry_name_item']			= 'Заголовок блока:';
$_['entry_description_item']	= 'Описание:';
$_['entry_link']				= 'Ссылка:';
$_['entry_add_item']			= 'Добавить блок';
$_['entry_item']				= 'Блок';
$_['entry_caption']				= 'Вкл / Выкл:';
$_['entry_child_block']			= 'Вкл / Выкл:';
$_['entry_class_wrapper']		= 'Class для родительского DIV-а:';
$_['entry_class_container']		= 'Class для контейнера блоков:';
$_['entry_class'] 				= 'Class:';
$_['entry_icon']				= 'Class иконки:';
$_['entry_id_wrapper']			= 'ID для родительского DIV-а:';
$_['entry_id_container']		= 'ID для контейнера блоков:';
$_['entry_id']					= 'ID:';
$_['entry_sort']				= 'Сортировка:';
$_['entry_status']				= 'Статус:';

//Help
$_['help_name_module']			= 'Заголовок будет отображаться в админке в списке модулей';
$_['help_name_wrapper']			= 'Заголовок который будет отображаться на сайте';
$_['help_icon']					= 'Например для FontAwesome пропишете: fa fa-font-awesome';
$_['help_radio_img_icon']		= 'Выберите, показывать изображение, иконку или выключить';
$_['help_child_block']			= 'Включить дополнительный Div или нет?';
$_['help_caption']				= 'Включить дополнительный Div или нет?';

// Error
$_['error_permission']			= 'У вас нет прав для редактирования модуля!';
$_['error_name']				= 'Название модуля должно быть от 3 до 64 символов!';

// Info
$_['entry_version']				= 'Версия';
$_['entry_support']				= 'Техническая поддержка';
$_['text_support']				= 'Отправить запрос в службу поддержки';
$_['entry_author']				= 'Разработчик';
$_['entry_documentation']		= 'Документация';