<?php
// Heading
$_['heading_title']				= 'HTML Pro';

// Text
$_['text_module']				= 'Module';
$_['text_extension']   			= 'Extensions';
$_['text_success']				= 'Success: You have modified HTML Pro module!';
$_['text_edit']					= 'Edit HTML Content Module';
$_['text_yes']					= 'Yes';
$_['text_no']					= 'No';
$_['text_off']					= 'Disabled';
$_['text_name_module']			= 'Module Name';
$_['text_name_wrapper']			= 'Title';
$_['text_name_item']			= 'Title';
$_['text_general_setting']		= 'General settings';
$_['text_item']					= 'Parent item';
$_['text_item_img_icon']		= 'Block for image or icon';
$_['text_image']				= 'Image';
$_['text_item_title']			= 'Block title';
$_['text_item_description']		= 'Block description';
$_['text_item_caption']			= 'Parent block for title and description';
$_['text_item_child_block']		= 'Child block';
$_['text_class']				= 'Class';
$_['text_id']					= 'ID';
$_['text_ico']					= 'Icon';
$_['text_icon']					= 'fa fa-font-awesome';
$_['text_sort']					= 'Sort';

// Tabs
$_['tab_setting']				= 'General';
$_['tab_items']					= 'Items';
$_['tab_info']					= 'About module';
$_['tab_item']					= 'Item';
$_['tab_id_class']				= 'Settings Class / ID';

// Entry
$_['entry_name_module']			= 'Module Name:';
$_['entry_name_wrapper']		= 'Title:';
$_['entry_name_item']			= 'Title:';
$_['entry_description_item']	= 'Description:';
$_['entry_link']				= 'Link:';
$_['entry_add_item']			= 'Add item';
$_['entry_item']				= 'Item';
$_['entry_caption']				= 'Enabled / Disabled:';
$_['entry_child_block']			= 'Enabled / Disabled:';
$_['entry_class_wrapper']		= 'Class for Parent DIV:';
$_['entry_class_container']		= 'Class for container item:';
$_['entry_class'] 				= 'Class:';
$_['entry_icon']				= 'Class icon:';
$_['entry_id_wrapper']			= 'ID for Parent DIV:';
$_['entry_id_container']		= 'ID for container item:';
$_['entry_id']					= 'ID:';
$_['entry_sort']				= 'Sort:';
$_['entry_status']				= 'Status:';

//Help
$_['help_name_module']			= 'The title will be displayed in the admin panel in the list of modules';
$_['help_name_wrapper']			= 'The title that will be displayed on the site';
$_['help_icon']					= 'For example, for FontAwesome, write: fa fa-font-awesome';
$_['help_radio_img_icon']		= 'Select, show image, icon or turn off';
$_['help_child_block']			= 'Enable additional Div or not?';
$_['help_caption']				= 'Enable additional Div or not?';

// Error
$_['error_permission']			= 'Warning: You do not have permission to modify HTML Pro module!';
$_['error_name']				= 'Module Name must be between 3 and 64 characters!';

// Info
$_['entry_version']				= 'Version';
$_['entry_support']				= 'Technical support';
$_['text_support']				= 'Send a request to the support team';
$_['entry_author']				= 'Developer';
$_['entry_documentation']		= 'Documentation';