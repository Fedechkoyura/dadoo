<?php
class ControllerExtensionModuleHtmlPro extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/module/html_pro');

		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();

		$this->document->setTitle(strip_tags($this->language->get('heading_title')));

		$this->load->model('extension/module');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			if (!isset($this->request->get['module_id'])) {
				$this->model_extension_module->addModule('html_pro', $this->request->post);
			} else {
				$this->model_extension_module->editModule($this->request->get['module_id'], $this->request->post);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true));
		}

		//CKEditor
		if ($this->config->get('config_editor_default')) {
			$this->document->addScript('view/javascript/ckeditor/ckeditor.js');
			$this->document->addScript('view/javascript/ckeditor/ckeditor_init.js');
		} else {
			$this->document->addScript('view/javascript/summernote/summernote.js');
			$this->document->addScript('view/javascript/summernote/lang/summernote-' . $this->language->get('lang') . '.js');
			$this->document->addScript('view/javascript/summernote/opencart.js');
			$this->document->addStyle('view/javascript/summernote/summernote.css');
		}

		$data['ckeditor'] = $this->config->get('config_editor_default');
		$data['token'] = $this->session->data['token'];

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_confirm'] = $this->language->get('text_confirm');
		$data['text_yes'] = $this->language->get('text_yes');
		$data['text_no'] = $this->language->get('text_no');
		$data['text_name_module'] = $this->language->get('text_name_module');
		$data['text_name_item'] = $this->language->get('text_name_item');
		$data['text_image'] = $this->language->get('text_image');
		$data['text_icon'] = $this->language->get('text_icon');
		$data['text_ico'] = $this->language->get('text_ico');
		$data['text_off'] = $this->language->get('text_off');
		$data['text_item'] = $this->language->get('text_item');
		$data['text_item_child_block'] = $this->language->get('text_item_child_block');
		$data['text_item_img_icon'] = $this->language->get('text_item_img_icon');
		$data['text_item_title'] = $this->language->get('text_item_title');
		$data['text_item_description'] = $this->language->get('text_item_description');
		$data['text_item_caption'] = $this->language->get('text_item_caption');
		$data['text_id'] = $this->language->get('text_id');
		$data['text_class'] = $this->language->get('text_class');
		$data['text_sort'] = $this->language->get('text_sort');
		$data['text_name_wrapper'] = $this->language->get('text_name_wrapper');
		$data['text_general_setting'] = $this->language->get('text_general_setting');

		$data['entry_name_module'] = $this->language->get('entry_name_module');
		$data['entry_name_wrapper'] = $this->language->get('entry_name_wrapper');
		$data['entry_name_item'] = $this->language->get('entry_name_item');
		$data['entry_description_item'] = $this->language->get('entry_description_item');
		$data['entry_link'] = $this->language->get('entry_link');
		$data['entry_add_item'] = $this->language->get('entry_add_item');
		$data['entry_item'] = $this->language->get('entry_item');
		$data['entry_child_block'] = $this->language->get('entry_child_block');
		$data['entry_caption'] = $this->language->get('entry_caption');
		$data['entry_class_wrapper'] = $this->language->get('entry_class_wrapper');
		$data['entry_class_container'] = $this->language->get('entry_class_container');
		$data['entry_class'] = $this->language->get('entry_class');
		$data['entry_icon'] = $this->language->get('entry_icon');
		$data['entry_id_wrapper'] = $this->language->get('entry_id_wrapper');
		$data['entry_id_container'] = $this->language->get('entry_id_container');
		$data['entry_id'] = $this->language->get('entry_id');
		$data['entry_sort'] = $this->language->get('entry_sort');
		$data['entry_status'] = $this->language->get('entry_status');

		$data['entry_version'] = $this->language->get('entry_version');
		$data['entry_support'] = $this->language->get('entry_support');
		$data['text_support'] = $this->language->get('text_support');
		$data['entry_author'] = $this->language->get('entry_author');
		$data['entry_documentation'] = $this->language->get('entry_documentation');

		$data['tab_setting'] = $this->language->get('tab_setting');
		$data['tab_items'] = $this->language->get('tab_items');
		$data['tab_item'] = $this->language->get('tab_item');
		$data['tab_id_class'] = $this->language->get('tab_id_class');
		$data['tab_info'] = $this->language->get('tab_info');

		$data['help_name_module'] = $this->language->get('help_name_module');
		$data['help_name_wrapper'] = $this->language->get('help_name_wrapper');
		$data['help_icon'] = $this->language->get('help_icon');
		$data['help_radio_img_icon'] = $this->language->get('help_radio_icon');
		$data['help_caption'] = $this->language->get('help_caption');
		$data['help_child_block'] = $this->language->get('help_child_block');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_module'),
			'href' => $this->url->link('extension/module', 'token=' . $this->session->data['token'] . '&type=module', true)
		);

		if (!isset($this->request->get['module_id'])) {
			$data['breadcrumbs'][] = array(
				'text' => strip_tags($this->language->get('heading_title')),
				'href' => $this->url->link('extension/module/html_pro', 'token=' . $this->session->data['token'], true)
			);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => strip_tags($this->language->get('heading_title')),
				'href' => $this->url->link('extension/module/html_pro', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], true)
			);
		}

		if (!isset($this->request->get['module_id'])) {
			$data['action'] = $this->url->link('extension/module/html_pro', 'token=' . $this->session->data['token'], true);
		} else {
			$data['action'] = $this->url->link('extension/module/html_pro', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], true);
		}

		$data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true);

		if (isset($this->request->get['module_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$module_info = $this->model_extension_module->getModule($this->request->get['module_id']);
		}

		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($module_info)) {
			$data['name'] = $module_info['name'];
		} else {
			$data['name'] = '';
		}

		if (isset($this->request->post['class_wrapper'])) {
			$data['class_wrapper'] = $this->request->post['class_wrapper'];
		} elseif (!empty($module_info)) {
			$data['class_wrapper'] = $module_info['class_wrapper'];
		} else {
			$data['class_wrapper'] = '';
		}

		if (isset($this->request->post['id_wrapper'])) {
			$data['id_wrapper'] = $this->request->post['id_wrapper'];
		} elseif (!empty($module_info)) {
			$data['id_wrapper'] = $module_info['id_wrapper'];
		} else {
			$data['id_wrapper'] = '';
		}

		if (isset($this->request->post['class_container'])) {
			$data['class_container'] = $this->request->post['class_container'];
		} elseif (!empty($module_info)) {
			$data['class_container'] = $module_info['class_container'];
		} else {
			$data['class_container'] = '';
		}

		if (isset($this->request->post['id_container'])) {
			$data['id_container'] = $this->request->post['id_container'];
		} elseif (!empty($module_info)) {
			$data['id_container'] = $module_info['id_container'];
		} else {
			$data['id_container'] = '';
		}

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($module_info)) {
			$data['status'] = $module_info['status'];
		} else {
			$data['status'] = '';
		}

		$this->load->model('tool/image');

		if (isset($this->request->post['wrapper'])) {
			$data['wrapper'] = $this->request->post['wrapper'];
		} elseif (!empty($module_info) & isset($module_info['wrapper'])) {
			$data['wrapper'] = $module_info['wrapper'];
		} else {
			$data['wrapper'] = array();
		}

		if (isset($this->request->post['item'])) {
			$results = $this->request->post['item'];
		} elseif (!empty($module_info) & isset($module_info['item'])) {
			$results = $module_info['item'];
		} else {
			$results = array();
		}

		$data['items'] = array();

		foreach ($results as $result) {

			if (is_file(DIR_IMAGE . $result['image'])) {
				$image = $result['image'];
				$thumb = $result['image'];
			} else {
				$image = '';
				$thumb = 'no_image.png';
			}

			$data['items'][] = array(
				'image' => $image,
				'thumb' => $this->model_tool_image->resize($thumb, 75, 75),
				'icon' => $result['icon'],
				'title' => $result['title'],
				'description' => $result['description'],
				'link' => $result['link'],
				'sort' => $result['sort'],
				'class_item' => $result['class_item'],
				'class_item_child_block' => $result['class_item_child_block'],
				'class_item_img_icon' => $result['class_item_img_icon'],
				'class_item_caption' => $result['class_item_caption'],
				'class_item_title' => $result['class_item_title'],
				'class_item_description' => $result['class_item_description'],
				'id_item' => $result['id_item'],
				'id_item_child_block' => $result['id_item_child_block'],
				'id_item_img_icon' => $result['id_item_img_icon'],
				'id_item_caption' => $result['id_item_caption'],
				'id_item_title' => $result['id_item_title'],
				'id_item_description' => $result['id_item_description'],
				'radio_child_block' => $result['radio_child_block'],
				'radio_img_icon' => $result['radio_img_icon'],
				'radio_caption' => $result['radio_caption']
			);
		}

		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 75, 75);

		$this->load->model('localisation/language');
		$data['languages'] = $this->model_localisation_language->getLanguages();

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/html_pro.tpl', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/html_pro')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 64)) {
			$this->error['name'] = $this->language->get('error_name');
		}

		return !$this->error;
	}
}
