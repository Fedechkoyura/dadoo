<?php
$_['text_widget_blogs']         = 'Список выбранных категорий';
$_['entry_image_adaptive_status']  = 'Адаптивный resize изображений<br><span class="help">После изменения состояния настройки, надо <br>очистить кеш картинок в папке /image/cache</span> ';

$_['text_widget_blogs_settings']       = 'Категории записей';
$_['order_blogs'] = '800';


$_['entry_anchor_templates'] = 'Шаблоны привязок';
$_['entry_anchor_value'] = 'Текущая величина';
$_['entry_anchor_templates_clear'] = 'Очистить';
$_['entry_anchor_templates_menu'] = 'Меню (default)';
$_['entry_anchor_templates_menu_1'] = 'Меню вариант (default)';
$_['entry_anchor_templates_footer'] = 'Footer меню (default)';
$_['entry_anchor_templates_footer_1'] = 'Footer меню вариант (default)';
$_['entry_anchor_templates_sitemap'] = 'Sitemap сайта (default)';
$_['entry_anchor_templates_html'] = 'html шаблон';
$_['entry_anchor_templates_prepend'] = 'prepend шаблон';
$_['entry_anchor_templates_append'] = 'append шаблон';
$_['entry_anchor_templates_before'] = 'before шаблон';
$_['entry_anchor_templates_after'] = 'after шаблон';
$_['text_anchor_templates_selector'] = 'ВВЕДИТЕ СЕЛЕКТОР TAG, #ID, .CLASS';

$_['entry_thumb_status'] = 'Показывать изображение категории';
$_['entry_avatar_dim'] = 'Размеры изображения категории';

$_['entry_box_begin_templates'] = 'Виджеты: блок обертки (начальный HTML код) шаблоны';
$_['entry_box_end_templates'] = 'Виджеты: блок обертки (закрывающий HTML-код) шаблоны';
$_['entry_box_begin_templates_tab'] = 'Блок (начальный HTML код) шаблон в вкладке (по умолчанию)';
$_['entry_box_end_templates_tab'] = 'Блок (закрывающий HTML-код) шаблон в вкладке (по умолчанию)';
$_['entry_box_begin_templates_empty'] = 'Блок (начальный HTML код) шаблон пустой блок (по умолчанию)';
$_['entry_box_end_templates_empty'] = 'Блок (закрывающий HTML-код) шаблон пустой блок (по умолчанию)';
$_['entry_box_begin_value'] = 'Текущее значение';
$_['entry_box_end_value'] = 'Текущее значение';

$_['text_separator']          = ' > ';
?>