<?php
$_['agoo_menu_modules'] = 'Модули';
$_['agoo_menu_options'] = 'Главная модуля';
$_['agoo_menu_layouts'] = 'Схемы';
$_['agoo_menu_widgets'] = 'Виджеты';
$_['agoo_menu_categories'] = 'Категории';
$_['agoo_menu_records'] = 'Записи';
$_['agoo_menu_comments'] = 'Комментарии';
$_['agoo_menu_reviews'] = 'Отзывы';
$_['agoo_menu_adapter'] = 'Адаптер шаблонов модуля под тему';
$_['agoo_menu_fields'] = 'Пользовательские поля форм';
$_['agoo_menu_sitemap'] = 'Sitemap';

?>