<?php
$_['text_widget_avatar'] = 'Avatar';
$_['text_widget_avatar_settings']       = 'Avatars';
$_['order_avatar'] = '21';
$_['entry_anchor_templates'] = 'Anchor templates';
$_['entry_anchor_value'] = 'Current value';
$_['entry_anchor_templates_clear'] = 'Clear input';

$_['entry_anchor_templates_avatar'] = 'In account (default)';
$_['entry_anchor_templates_avatar_reviews'] = 'In reviews (default)';

$_['entry_anchor_templates_html'] = 'html template';
$_['entry_anchor_templates_prepend'] = 'prepend template';
$_['entry_anchor_templates_append'] = 'append template';
$_['entry_anchor_templates_before'] = 'before template';
$_['entry_anchor_templates_after'] = 'after template';
$_['text_anchor_templates_selector'] = 'TYPE TAG, #ID, .CLASS SELECTOR';


$_['entry_box_begin_templates'] = 'Block (initial HTML code) templates';
$_['entry_box_end_templates'] = 'Block (closing HTML code) templates';
$_['entry_box_begin_templates_tab'] = 'Block (initial HTML code) templates in tab (default)';
$_['entry_box_end_templates_tab'] = 'Block (closing HTML code) templates in tab (default)';
$_['entry_box_begin_templates_empty'] = 'Block (initial HTML code) templates empty block (default)';
$_['entry_box_end_templates_empty'] = 'Block (closing HTML code) templates empty block (default)';
$_['entry_box_begin_value'] = 'Current value';
$_['entry_box_end_value'] = 'Current value';


?>