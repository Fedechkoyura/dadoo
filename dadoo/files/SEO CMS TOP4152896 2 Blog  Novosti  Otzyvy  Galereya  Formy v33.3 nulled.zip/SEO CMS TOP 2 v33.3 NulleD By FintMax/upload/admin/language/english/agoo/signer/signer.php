<?php
$_['hide_block'] = 'Close';
$_['text_signer'] = 'Watch for replies';
$_['text_customer'] = 'User';
$_['text_write'] = 'wrote the answer to the records';
$_['error_customer_id'] = 'Subscribe may only registered users';
$_['error_register'] = 'Register';
$_['error_no_signer'] = 'Not set';
$_['success_set'] = 'You have subscribed for replies';
$_['success_remove'] = "You've passed from answers";
$_['text_date'] = ' d M Y';
$_['text_hours'] = " H:i:s";
$_['text_today'] = "Today";
$_['text_greeting'] = '%s';
$_['text_no_answer'] = 'Please, do not reply to this letter.';
$_['text_rating'] = 'And set the assessment: ';
$_['text_subject'] = "%s - You came the reply";
$_['text_or_email'] = "<b>E-mail</b> to subscribe or unsubscribe";
$_['text_un_email'] = "<b>E-mail</b> to unsubscribe";
$_['text_subscribe'] = "Subscribe / Unsubscribe";
$_['text_unsubscribe'] = "Unsubscribe";
$_['text_ghost'] = 'Guest';
$_['text_email_error'] = 'Not valid e-mail format';
$_['text_noemail_error']= 'Fill in the e-mail';
?>