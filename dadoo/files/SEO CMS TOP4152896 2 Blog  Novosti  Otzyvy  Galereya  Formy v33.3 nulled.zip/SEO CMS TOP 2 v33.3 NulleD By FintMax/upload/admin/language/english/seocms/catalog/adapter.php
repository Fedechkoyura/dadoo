<?php
$_['heading_title'] = 'Adapter';
$_['entry_title'] = 'Title';
$_['button_adapter'] = 'Adapt';
$_['column_name'] = 'Theme name';
$_['url_adapter_text'] = 'Adapter';
$_['theme_status'] = ' (<b>current theme</b>)';
$_['url_back_text'] = 'Back in the module settings';
$_['column_action'] = 'Action';
$_['column_image'] = 'Image';
$_['column_id'] = 'ID';
//$_['text_edit'] = 'Adapt<br>through (success.tpl)';
$_['text_edit'] = 'Adapt';
$_['text_edit_compare'] = 'Adapt<br>through (compare.tpl)';
$_['text_success'] = 'Template files of the module successfully adapted to the chosen topic';
$_['text_error_warning']= 'Attention, error in adapting templates module selected under the theme';
$_['text_no_results'] = 'Not found a single theme. Are you sure that the settings are correct?';
$_['entry_success'] = 'Contents of the file themes <br>';
$_['entry_remove_class']= 'Delete item class, together with the content';
$_['entry_remove_id'] = 'Delete item id, together with the content';
$_['entry_remove_tag'] = 'Delete item, together with the content';
$_['entry_replace_breadcrumb'] = 'Replace unit breadcrumb on the block breadcrumb module file';
$_['entry_replace_breadcrumb_name'] = 'Selector breadcrumb unit to replace';
$_['entry_replace_main_name'] = 'Text to replace the content of the module file';
$_['error_name'] = 'Not a valid theme';
$_['error_warning'] = 'Error';
$_['error_permission'] = 'You do not have permissions to change';
$_['url_adapter_text'] = 'Adapter';


?>