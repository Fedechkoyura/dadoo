<?php
include(DIR_LANGUAGE.'english/feed/google_sitemap_blog.php');
