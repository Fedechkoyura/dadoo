<?php
include(DIR_LANGUAGE.'english/module/blog.php');