<?php
include(DIR_LANGUAGE.'english/agoo/reviews/reviews.php');
