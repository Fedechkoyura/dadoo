<?php
include(DIR_LANGUAGE.'english/seocms/agooa/adminmenu.php');