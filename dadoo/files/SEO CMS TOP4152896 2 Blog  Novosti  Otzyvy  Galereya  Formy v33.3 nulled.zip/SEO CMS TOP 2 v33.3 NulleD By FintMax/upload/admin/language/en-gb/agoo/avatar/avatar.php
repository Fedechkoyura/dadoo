<?php
include(DIR_LANGUAGE.'english/agoo/avatar/avatar.php');
