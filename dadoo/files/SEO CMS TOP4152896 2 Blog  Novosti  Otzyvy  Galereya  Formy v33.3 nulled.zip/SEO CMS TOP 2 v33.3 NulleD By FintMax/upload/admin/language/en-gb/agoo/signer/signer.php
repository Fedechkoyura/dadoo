<?php
include(DIR_LANGUAGE.'english/agoo/signer/signer.php');
