<?php
include(DIR_LANGUAGE.'english/seocms/catalog/record.php');
