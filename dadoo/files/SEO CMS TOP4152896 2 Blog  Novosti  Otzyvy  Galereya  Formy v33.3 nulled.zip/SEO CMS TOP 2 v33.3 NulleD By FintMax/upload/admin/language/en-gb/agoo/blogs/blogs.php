<?php
include(DIR_LANGUAGE.'english/agoo/blogs/blogs.php');
