<?php
include(DIR_LANGUAGE.'english/agoo/related/related.php');
