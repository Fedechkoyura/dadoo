<?php
include(DIR_LANGUAGE.'english/seocms/catalog/fields.php');
