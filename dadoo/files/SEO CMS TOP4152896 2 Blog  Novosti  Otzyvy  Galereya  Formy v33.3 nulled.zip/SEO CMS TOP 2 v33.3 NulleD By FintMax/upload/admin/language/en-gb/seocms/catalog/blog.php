<?php
include(DIR_LANGUAGE.'english/seocms/catalog/blog.php');
