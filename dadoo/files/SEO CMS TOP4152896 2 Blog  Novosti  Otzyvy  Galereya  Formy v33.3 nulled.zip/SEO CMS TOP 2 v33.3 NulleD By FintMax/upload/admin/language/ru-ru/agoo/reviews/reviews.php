<?php
include(DIR_LANGUAGE.'russian/agoo/reviews/reviews.php');
