<?php
include(DIR_LANGUAGE.'russian/agoo/latest/latest.php');
