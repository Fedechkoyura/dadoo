<?php
include(DIR_LANGUAGE.'russian/seocms/catalog/blog.php');
