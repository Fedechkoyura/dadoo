<?php
include(DIR_LANGUAGE.'russian/agoo/blogs/blogs.php');
