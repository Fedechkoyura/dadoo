<?php
include(DIR_LANGUAGE.'russian/seocms/catalog/comment.php');
