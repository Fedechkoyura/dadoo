<?php
include(DIR_LANGUAGE.'russian/feed/google_sitemap_blog.php');
