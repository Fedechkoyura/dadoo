<?php
include(DIR_LANGUAGE.'russian/seocms/agooa/adminmenu.php');