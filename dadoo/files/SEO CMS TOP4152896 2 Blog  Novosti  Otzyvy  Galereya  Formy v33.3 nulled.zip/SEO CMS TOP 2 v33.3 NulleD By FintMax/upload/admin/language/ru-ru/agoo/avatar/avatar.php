<?php
include(DIR_LANGUAGE.'russian/agoo/avatar/avatar.php');
