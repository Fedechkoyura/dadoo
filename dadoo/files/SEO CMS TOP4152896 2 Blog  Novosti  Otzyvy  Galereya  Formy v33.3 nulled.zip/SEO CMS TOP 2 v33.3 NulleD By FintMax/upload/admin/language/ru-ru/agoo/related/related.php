<?php
include(DIR_LANGUAGE.'russian/agoo/related/related.php');
