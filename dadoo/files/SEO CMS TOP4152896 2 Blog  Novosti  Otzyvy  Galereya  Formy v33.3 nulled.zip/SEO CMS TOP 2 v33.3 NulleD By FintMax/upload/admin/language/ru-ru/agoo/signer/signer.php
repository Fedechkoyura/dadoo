<?php
include(DIR_LANGUAGE.'russian/agoo/signer/signer.php');
