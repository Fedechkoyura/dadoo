<?php
include(DIR_LANGUAGE.'russian/module/blog.php');
