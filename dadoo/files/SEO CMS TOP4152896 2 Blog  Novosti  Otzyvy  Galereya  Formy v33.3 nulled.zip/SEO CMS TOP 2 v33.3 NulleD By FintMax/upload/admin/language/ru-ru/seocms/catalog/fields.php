<?php
include(DIR_LANGUAGE.'russian/seocms/catalog/fields.php');
