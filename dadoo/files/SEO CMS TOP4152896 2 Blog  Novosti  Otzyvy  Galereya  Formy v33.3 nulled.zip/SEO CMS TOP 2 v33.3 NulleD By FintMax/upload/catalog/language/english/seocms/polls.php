<?php

$_['text_success'] = 'Thank you';
$_['text_write'] = 'Your option';
$_['text_tab'] = 'Response options';
$_['text_all'] = 'Total: ';
$_['text_result'] = 'Results';
$_['text_review_yes']   = 'Vote';
?>