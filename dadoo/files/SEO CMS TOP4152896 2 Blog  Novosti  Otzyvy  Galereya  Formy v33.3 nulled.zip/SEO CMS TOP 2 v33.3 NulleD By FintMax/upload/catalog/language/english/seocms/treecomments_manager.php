<?php
$_['entry_comment']         = 'Ваш вопрос:';
?>