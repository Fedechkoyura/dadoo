<?php
$_['text_write']      = 'Задать вопрос';
$_['text_write_review']  = 'Задать вопрос';
$_['entry_comment']      = 'Ваш вопрос';
$_['text_reply_button']	 ='Задать вопрос';
$_['tab_comment']		= 'Вопросы-ответы';
?>