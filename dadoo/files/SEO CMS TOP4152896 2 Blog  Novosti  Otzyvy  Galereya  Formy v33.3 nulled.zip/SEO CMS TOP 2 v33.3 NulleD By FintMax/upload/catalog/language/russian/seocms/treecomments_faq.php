<?php
$_['text_write']      = 'Задать вопрос';
$_['text_write_review']  = 'Задать вопрос';
$_['entry_comment']      = 'Ваш вопрос';
$_['text_reply_button']	 ='Задать вопрос';
$_['tab_comment']		= 'Вопросы-ответы';
$_['error_text']        = 'Текст отзыва должен быть от 3 до 1000 символов!';
$_['text_no_comments']	= '';
?>