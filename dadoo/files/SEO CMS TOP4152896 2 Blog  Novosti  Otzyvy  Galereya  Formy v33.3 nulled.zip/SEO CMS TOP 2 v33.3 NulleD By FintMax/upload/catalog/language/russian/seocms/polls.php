<?php
$_['text_success']      = 'Спасибо';
$_['text_write']		= 'Ваш вариант ответа';
$_['text_tab']			= 'Варианты ответов';
$_['text_all']			= 'Всего: ';
$_['text_result']		= 'Результаты';
$_['text_review_yes']   = 'Голосовать';
$_['entry_comment']     = 'Ваш ответ:';
?>