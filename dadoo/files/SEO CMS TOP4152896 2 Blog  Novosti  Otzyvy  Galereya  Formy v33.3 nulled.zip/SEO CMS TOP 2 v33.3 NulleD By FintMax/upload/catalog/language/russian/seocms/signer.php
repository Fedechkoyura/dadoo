<?php
$_['hide_block'] 		= 'закрыть';
$_['text_signer']       = 'Следить за отзывами';
$_['text_error_email']= 'Не правильный e-mail';
$_['text_customer']     = 'Пользователь';
$_['text_write']        = 'написал ответ к записи';
$_['error_customer_id'] = 'Подписываться могут только зарегистрированные пользователи';
$_['error_register']    = 'Регистрация';
$_['error_no_signer']   = 'Не установлены настройки';
$_['success_set']       = 'Вы подписаны на отзывы';
$_['success_remove']    = 'Вы отписаны от отзывов';
$_['text_date']         = "d M Y";
$_['text_hours']        = " в H:i:s";
$_['text_today']        = "Сегодня";
$_['text_greeting']     = 'Уважаемый(ая) %s';
$_['text_no_answer']    = 'Пожайлуста, не отвечайте на это письмо.';
$_['text_rating']       = 'И поставил оценку: ';
$_['text_subject']      = '%s - Вам пришел ответ';
$_['text_or_email']     = "Или <b>e-mail</b> для подписки или отписаться";
$_['text_un_email']     = "Или <b>e-mail</b> чтобы отписаться";
$_['text_subscribe']    = "Подписаться / Отписаться";
$_['text_unsubscribe']  = "Отписаться";
$_['text_ghost']        = 'Гость';
$_['text_email_error']  = 'Не правильный формат e-mail';
$_['text_noemail_error']= 'Заполните поле e-mail';
?>