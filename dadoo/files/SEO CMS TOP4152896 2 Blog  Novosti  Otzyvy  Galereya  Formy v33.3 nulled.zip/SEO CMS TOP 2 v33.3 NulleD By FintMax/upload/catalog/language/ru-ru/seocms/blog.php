<?php
include(DIR_LANGUAGE.'russian/seocms/blog.php');
