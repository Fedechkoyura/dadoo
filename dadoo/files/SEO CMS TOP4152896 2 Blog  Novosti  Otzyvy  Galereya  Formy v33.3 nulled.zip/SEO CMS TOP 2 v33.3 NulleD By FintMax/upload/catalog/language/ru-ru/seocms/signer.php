<?php
include(DIR_LANGUAGE.'russian/seocms/signer.php');
