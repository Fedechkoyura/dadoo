<?php
include(DIR_LANGUAGE.'russian/seocms/module.php');
