<?php
include(DIR_LANGUAGE.'english/seocms/record.php');
