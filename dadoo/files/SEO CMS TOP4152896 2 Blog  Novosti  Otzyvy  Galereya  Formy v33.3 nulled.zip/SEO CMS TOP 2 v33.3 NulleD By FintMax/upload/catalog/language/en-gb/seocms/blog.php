<?php
include(DIR_LANGUAGE.'english/seocms/blog.php');
