<?php
include(DIR_LANGUAGE.'english/seocms/signer.php');
