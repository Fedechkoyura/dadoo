<?php
include(DIR_LANGUAGE.'english/seocms/google_sitemap_blog.php');
